const { hot } = require("react-hot-loader/root")

// prefer default export if available
const preferDefault = m => m && m.default || m


exports.components = {
  "component---src-components-paginas-js": hot(preferDefault(require("/Users/juandelatorre/Desktop/bienesraicesfrontend/src/components/paginas.js"))),
  "component---src-components-propiedades-js": hot(preferDefault(require("/Users/juandelatorre/Desktop/bienesraicesfrontend/src/components/propiedades.js"))),
  "component---src-pages-index-js": hot(preferDefault(require("/Users/juandelatorre/Desktop/bienesraicesfrontend/src/pages/index.js")))
}

